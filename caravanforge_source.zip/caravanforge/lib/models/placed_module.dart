import 'package:flutter/material.dart';
import 'module_type.dart';

/// Represents a single placed module on the design canvas.
/// All positions and sizes are in grid units.
class PlacedModule {
  final String id;
  final ModuleType type;
  double gridX; // Column position in grid units
  double gridY; // Row position in grid units
  double gridWidth; // Width in grid units
  double gridHeight; // Height in grid units

  PlacedModule({
    required this.id,
    required this.type,
    required this.gridX,
    required this.gridY,
    required this.gridWidth,
    required this.gridHeight,
  });

  /// Creates a copy with optionally updated fields.
  PlacedModule copyWith({
    String? id,
    ModuleType? type,
    double? gridX,
    double? gridY,
    double? gridWidth,
    double? gridHeight,
  }) {
    return PlacedModule(
      id: id ?? this.id,
      type: type ?? this.type,
      gridX: gridX ?? this.gridX,
      gridY: gridY ?? this.gridY,
      gridWidth: gridWidth ?? this.gridWidth,
      gridHeight: gridHeight ?? this.gridHeight,
    );
  }

  /// Converts to JSON map for persistence.
  Map<String, dynamic> toJson() => {
        'id': id,
        'type': type.name,
        'gridX': gridX,
        'gridY': gridY,
        'gridWidth': gridWidth,
        'gridHeight': gridHeight,
      };

  /// Creates a PlacedModule from a JSON map.
  factory PlacedModule.fromJson(Map<String, dynamic> json) {
    final typeName = json['type'] as String;
    final moduleType = ModuleType.values.firstWhere(
      (e) => e.name == typeName,
      orElse: () => ModuleType.storage,
    );
    return PlacedModule(
      id: json['id'] as String,
      type: moduleType,
      gridX: (json['gridX'] as num).toDouble(),
      gridY: (json['gridY'] as num).toDouble(),
      gridWidth: (json['gridWidth'] as num).toDouble(),
      gridHeight: (json['gridHeight'] as num).toDouble(),
    );
  }

  /// Returns the pixel rect for this module given a grid unit size.
  Rect toPixelRect(double gridUnit) {
    return Rect.fromLTWH(
      gridX * gridUnit,
      gridY * gridUnit,
      gridWidth * gridUnit,
      gridHeight * gridUnit,
    );
  }
}
