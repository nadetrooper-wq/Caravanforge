import 'package:flutter/material.dart';

/// Defines all available caravan room/module types.
enum ModuleType {
  bedroom,
  kitchen,
  bathroom,
  livingArea,
  storage,
  diningArea,
  wardrobe,
  entrance,
}

/// Extension providing display metadata for each module type.
extension ModuleTypeExtension on ModuleType {
  String get label {
    switch (this) {
      case ModuleType.bedroom:
        return 'Bedroom';
      case ModuleType.kitchen:
        return 'Kitchen';
      case ModuleType.bathroom:
        return 'Bathroom';
      case ModuleType.livingArea:
        return 'Living Area';
      case ModuleType.storage:
        return 'Storage';
      case ModuleType.diningArea:
        return 'Dining Area';
      case ModuleType.wardrobe:
        return 'Wardrobe';
      case ModuleType.entrance:
        return 'Entrance';
    }
  }

  IconData get icon {
    switch (this) {
      case ModuleType.bedroom:
        return Icons.bed;
      case ModuleType.kitchen:
        return Icons.microwave;
      case ModuleType.bathroom:
        return Icons.bathtub;
      case ModuleType.livingArea:
        return Icons.weekend;
      case ModuleType.storage:
        return Icons.inventory_2;
      case ModuleType.diningArea:
        return Icons.dining;
      case ModuleType.wardrobe:
        return Icons.checkroom;
      case ModuleType.entrance:
        return Icons.door_front;
    }
  }

  Color get color {
    switch (this) {
      case ModuleType.bedroom:
        return const Color(0xFF5C6BC0); // Indigo
      case ModuleType.kitchen:
        return const Color(0xFF26A69A); // Teal
      case ModuleType.bathroom:
        return const Color(0xFF29B6F6); // Light Blue
      case ModuleType.livingArea:
        return const Color(0xFF66BB6A); // Green
      case ModuleType.storage:
        return const Color(0xFF8D6E63); // Brown
      case ModuleType.diningArea:
        return const Color(0xFFFFA726); // Orange
      case ModuleType.wardrobe:
        return const Color(0xFFAB47BC); // Purple
      case ModuleType.entrance:
        return const Color(0xFFEF5350); // Red
    }
  }

  /// Default size in canvas grid units (each unit = 20px).
  /// Width x Height — realistic floor plan proportions.
  Size get defaultGridSize {
    switch (this) {
      case ModuleType.bedroom:
        return const Size(8, 6);
      case ModuleType.kitchen:
        return const Size(6, 4);
      case ModuleType.bathroom:
        return const Size(4, 4);
      case ModuleType.livingArea:
        return const Size(8, 5);
      case ModuleType.storage:
        return const Size(3, 3);
      case ModuleType.diningArea:
        return const Size(5, 4);
      case ModuleType.wardrobe:
        return const Size(4, 2);
      case ModuleType.entrance:
        return const Size(3, 2);
    }
  }
}
