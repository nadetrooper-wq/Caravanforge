import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'providers/canvas_model.dart';
import 'screens/home_screen.dart';
import 'utils/app_theme.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const CaravanForgeApp());
}

class CaravanForgeApp extends StatelessWidget {
  const CaravanForgeApp({super.key});

  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider(
      create: (_) => CanvasModel()..loadSaved(),
      child: MaterialApp(
        title: 'CaravanForge',
        theme: AppTheme.dark,
        debugShowCheckedModeBanner: false,
        home: const HomeScreen(),
      ),
    );
  }
}
