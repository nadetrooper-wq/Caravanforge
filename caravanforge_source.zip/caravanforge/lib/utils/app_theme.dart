import 'package:flutter/material.dart';

class AppTheme {
  AppTheme._();

  static const Color background = Color(0xFF121212);
  static const Color surface = Color(0xFF1E1E1E);
  static const Color surfaceVariant = Color(0xFF2C2C2C);
  static const Color accent = Color(0xFFFFB300);
  static const Color accentLight = Color(0xFFFFE082);
  static const Color onSurface = Color(0xFFE0E0E0);
  static const Color canvasBg = Color(0xFF1A1A2E);
  static const Color gridLine = Color(0xFF252538);
  static const Color selectionBorder = Color(0xFFFFB300);
  static const Color handleColor = Color(0xFFFFFFFF);

  static ThemeData get dark {
    return ThemeData(
      brightness: Brightness.dark,
      scaffoldBackgroundColor: background,
      colorScheme: const ColorScheme.dark(
        primary: accent,
        secondary: accentLight,
        surface: surface,
        onPrimary: Colors.black,
        onSecondary: Colors.black,
        onSurface: onSurface,
      ),
      appBarTheme: const AppBarTheme(
        backgroundColor: surface,
        elevation: 0,
        iconTheme: IconThemeData(color: onSurface),
        titleTextStyle: TextStyle(
          color: onSurface,
          fontSize: 18,
          fontWeight: FontWeight.w600,
          letterSpacing: 0.5,
        ),
      ),
      elevatedButtonTheme: ElevatedButtonThemeData(
        style: ElevatedButton.styleFrom(
          backgroundColor: accent,
          foregroundColor: Colors.black,
          textStyle: const TextStyle(fontWeight: FontWeight.bold),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
        ),
      ),
      cardTheme: CardTheme(
        color: surfaceVariant,
        elevation: 0,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      ),
      textTheme: const TextTheme(
        titleLarge: TextStyle(color: onSurface, fontWeight: FontWeight.bold, fontSize: 20),
        titleMedium: TextStyle(color: onSurface, fontWeight: FontWeight.w600, fontSize: 16),
        bodyMedium: TextStyle(color: onSurface, fontSize: 14),
        labelSmall: TextStyle(color: Colors.white70, fontSize: 11),
      ),
      dividerTheme: const DividerThemeData(color: Color(0xFF3A3A3A)),
    );
  }
}
