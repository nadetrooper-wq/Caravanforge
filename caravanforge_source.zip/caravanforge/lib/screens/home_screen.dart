import 'package:flutter/material.dart';
import '../utils/app_theme.dart';
import 'designer_screen.dart';

/// Welcome / home screen shown on app launch.
class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.background,
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 32),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              // Logo / branding
              const Icon(
                Icons.architecture,
                color: AppTheme.accent,
                size: 72,
              ),
              const SizedBox(height: 24),
              Text(
                'CaravanForge',
                style: Theme.of(context).textTheme.titleLarge?.copyWith(
                      fontSize: 32,
                      letterSpacing: 1.5,
                    ),
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 8),
              const Text(
                'Design your perfect caravan floor plan',
                textAlign: TextAlign.center,
                style: TextStyle(color: Colors.white54, fontSize: 14),
              ),
              const SizedBox(height: 56),

              // Feature bullets
              ..._features.map(
                (f) => Padding(
                  padding: const EdgeInsets.symmetric(vertical: 6),
                  child: Row(
                    children: [
                      Icon(f.$1, color: AppTheme.accent, size: 18),
                      const SizedBox(width: 12),
                      Text(f.$2,
                          style: const TextStyle(
                              color: Colors.white70, fontSize: 13)),
                    ],
                  ),
                ),
              ),

              const SizedBox(height: 48),

              // CTA button
              ElevatedButton(
                onPressed: () {
                  Navigator.of(context).push(MaterialPageRoute(
                    builder: (_) => const DesignerScreen(),
                  ));
                },
                style: ElevatedButton.styleFrom(
                  padding: const EdgeInsets.symmetric(vertical: 16),
                ),
                child: const Text('Start Designing',
                    style: TextStyle(fontSize: 16)),
              ),

              const SizedBox(height: 16),
              const Text(
                'Your designs are saved automatically',
                textAlign: TextAlign.center,
                style: TextStyle(color: Colors.white38, fontSize: 11),
              ),
            ],
          ),
        ),
      ),
    );
  }

  static const _features = [
    (Icons.drag_indicator, 'Drag & drop 8 room types onto the canvas'),
    (Icons.grid_4x4, 'Snap-to-grid alignment for clean layouts'),
    (Icons.open_with, 'Resize modules with corner handles'),
    (Icons.history, 'Unlimited undo / redo'),
    (Icons.save, 'Auto-saves your design locally'),
  ];
}
