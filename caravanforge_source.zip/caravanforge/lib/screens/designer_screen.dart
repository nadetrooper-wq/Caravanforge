import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../models/placed_module.dart';
import '../providers/canvas_model.dart';
import '../utils/app_theme.dart';
import '../widgets/canvas_painter.dart';
import '../widgets/module_panel.dart';
import '../widgets/module_widget.dart';

/// Main design canvas screen.
class DesignerScreen extends StatelessWidget {
  const DesignerScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.background,
      appBar: const _DesignerAppBar(),
      body: const _DesignerBody(),
      floatingActionButton: const _AddModuleFab(),
    );
  }
}

/// AppBar with undo/redo, delete, snap toggle, and clear actions.
class _DesignerAppBar extends StatelessWidget implements PreferredSizeWidget {
  const _DesignerAppBar();

  @override
  Size get preferredSize => const Size.fromHeight(kToolbarHeight);

  @override
  Widget build(BuildContext context) {
    final model = context.watch<CanvasModel>();

    return AppBar(
      title: const Row(
        children: [
          Icon(Icons.architecture, color: AppTheme.accent, size: 20),
          SizedBox(width: 8),
          Text('Design Canvas'),
        ],
      ),
      actions: [
        Tooltip(
          message: 'Undo',
          child: IconButton(
            icon: const Icon(Icons.undo),
            onPressed: model.canUndo ? () => context.read<CanvasModel>().undo() : null,
          ),
        ),
        Tooltip(
          message: 'Redo',
          child: IconButton(
            icon: const Icon(Icons.redo),
            onPressed: model.canRedo ? () => context.read<CanvasModel>().redo() : null,
          ),
        ),
        Tooltip(
          message: 'Delete selected',
          child: IconButton(
            icon: Icon(
              Icons.delete_outline,
              color: model.selectedId != null ? Colors.redAccent : null,
            ),
            onPressed: model.selectedId != null
                ? () => context.read<CanvasModel>().deleteSelected()
                : null,
          ),
        ),
        Tooltip(
          message: model.snapToGrid ? 'Snap: ON' : 'Snap: OFF',
          child: IconButton(
            icon: Icon(
              Icons.grid_4x4,
              color: model.snapToGrid ? AppTheme.accent : Colors.white38,
            ),
            onPressed: () => context.read<CanvasModel>().toggleSnapToGrid(),
          ),
        ),
        PopupMenuButton<String>(
          icon: const Icon(Icons.more_vert),
          color: AppTheme.surfaceVariant,
          onSelected: (value) async {
            if (value == 'clear') {
              final confirmed = await _confirmClear(context);
              if (confirmed && context.mounted) {
                context.read<CanvasModel>().clearCanvas();
              }
            } else if (value == 'export') {
              if (context.mounted) _showExport(context);
            }
          },
          itemBuilder: (_) => const [
            PopupMenuItem(
              value: 'clear',
              child: Row(children: [
                Icon(Icons.clear_all, color: Colors.redAccent, size: 18),
                SizedBox(width: 10),
                Text('Clear Canvas'),
              ]),
            ),
            PopupMenuItem(
              value: 'export',
              child: Row(children: [
                Icon(Icons.code, color: AppTheme.accent, size: 18),
                SizedBox(width: 10),
                Text('Export JSON'),
              ]),
            ),
          ],
        ),
      ],
    );
  }

  Future<bool> _confirmClear(BuildContext context) async {
    return await showDialog<bool>(
          context: context,
          builder: (ctx) => AlertDialog(
            backgroundColor: AppTheme.surfaceVariant,
            title: const Text('Clear Canvas'),
            content: const Text('Remove all modules? This can be undone.'),
            actions: [
              TextButton(
                  onPressed: () => Navigator.pop(ctx, false),
                  child: const Text('Cancel')),
              TextButton(
                  onPressed: () => Navigator.pop(ctx, true),
                  child: const Text('Clear',
                      style: TextStyle(color: Colors.redAccent))),
            ],
          ),
        ) ??
        false;
  }

  void _showExport(BuildContext context) {
    final json = context.read<CanvasModel>().exportJson();
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: AppTheme.surfaceVariant,
        title: const Text('Export JSON'),
        content: ConstrainedBox(
          constraints: const BoxConstraints(maxHeight: 300),
          child: SingleChildScrollView(
            child: SelectableText(
              json,
              style: const TextStyle(
                  fontSize: 11,
                  fontFamily: 'monospace',
                  color: Colors.white70),
            ),
          ),
        ),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(ctx),
              child: const Text('Close')),
        ],
      ),
    );
  }
}

/// Scrollable canvas area.
class _DesignerBody extends StatelessWidget {
  const _DesignerBody();

  @override
  Widget build(BuildContext context) {
    final selectedModule = context.select<CanvasModel, PlacedModule?>(
        (m) => m.selectedModule);

    return Column(
      children: [
        if (selectedModule != null)
          _SelectionInfoBar(module: selectedModule),
        Expanded(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(24),
            child: Center(
              child: SingleChildScrollView(
                scrollDirection: Axis.horizontal,
                child: const _Canvas(),
              ),
            ),
          ),
        ),
      ],
    );
  }
}

/// The actual canvas widget with all modules.
class _Canvas extends StatelessWidget {
  const _Canvas();

  @override
  Widget build(BuildContext context) {
    final model = context.watch<CanvasModel>();

    return GestureDetector(
      onTap: () => model.selectModule(null),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(30),
        child: SizedBox(
          width: model.canvasWidth,
          height: model.canvasHeight,
          child: CustomPaint(
            painter: CanvasPainter(showGrid: model.snapToGrid),
            child: Stack(
              clipBehavior: Clip.hardEdge,
              children: [
                for (final module in model.modules)
                  ModuleWidget(key: ValueKey(module.id), module: module),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

/// Thin info bar showing selected module details.
class _SelectionInfoBar extends StatelessWidget {
  final PlacedModule module;
  const _SelectionInfoBar({required this.module});

  @override
  Widget build(BuildContext context) {
    final w = (module.gridWidth * CanvasModel.gridUnit / 10).toStringAsFixed(1);
    final h = (module.gridHeight * CanvasModel.gridUnit / 10).toStringAsFixed(1);

    return Container(
      width: double.infinity,
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
      color: AppTheme.surfaceVariant,
      child: Row(
        children: [
          Icon(module.type.icon, color: module.type.color, size: 16),
          const SizedBox(width: 8),
          Text(
            module.type.label,
            style: const TextStyle(
                color: Colors.white, fontWeight: FontWeight.w600, fontSize: 13),
          ),
          const SizedBox(width: 12),
          Text(
            '${w}m × ${h}m',
            style: const TextStyle(color: Colors.white54, fontSize: 12),
          ),
          const Spacer(),
          GestureDetector(
            onTap: () => context.read<CanvasModel>().deleteSelected(),
            child: const Row(
              children: [
                Icon(Icons.delete_outline, color: Colors.redAccent, size: 16),
                SizedBox(width: 4),
                Text('Delete',
                    style: TextStyle(color: Colors.redAccent, fontSize: 12)),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

/// FAB to open the add-module panel.
class _AddModuleFab extends StatelessWidget {
  const _AddModuleFab();

  @override
  Widget build(BuildContext context) {
    return FloatingActionButton.extended(
      onPressed: () => ModulePanel.show(context),
      backgroundColor: AppTheme.accent,
      foregroundColor: Colors.black,
      icon: const Icon(Icons.add),
      label: const Text(
        'Add Module',
        style: TextStyle(fontWeight: FontWeight.bold),
      ),
    );
  }
}
