import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../models/placed_module.dart';
import '../providers/canvas_model.dart';
import '../utils/app_theme.dart';

/// Renders a single placed module with drag, selection, and resize handles.
class ModuleWidget extends StatelessWidget {
  final PlacedModule module;
  const ModuleWidget({super.key, required this.module});

  static const double _handleSize = 14.0;

  @override
  Widget build(BuildContext context) {
    final model = context.read<CanvasModel>();
    final isSelected = context.select<CanvasModel, bool>(
        (m) => m.selectedId == module.id);
    final g = CanvasModel.gridUnit;

    final left = module.gridX * g;
    final top = module.gridY * g;
    final width = module.gridWidth * g;
    final height = module.gridHeight * g;

    return Positioned(
      left: left,
      top: top,
      width: width,
      height: height,
      child: GestureDetector(
        onTap: () => model.selectModule(module.id),
        onPanUpdate: (d) {
          model.moveModule(module.id, d.delta.dx, d.delta.dy);
        },
        onPanEnd: (_) {
          model.snapMove(module.id);
          model.commitMove();
        },
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 150),
          decoration: BoxDecoration(
            color: module.type.color.withOpacity(0.85),
            borderRadius: BorderRadius.circular(6),
            border: Border.all(
              color: isSelected ? AppTheme.selectionBorder : module.type.color,
              width: isSelected ? 2.5 : 1.0,
            ),
            boxShadow: isSelected
                ? [
                    BoxShadow(
                      color: AppTheme.selectionBorder.withOpacity(0.4),
                      blurRadius: 8,
                      spreadRadius: 1,
                    )
                  ]
                : [
                    BoxShadow(
                      color: Colors.black.withOpacity(0.3),
                      blurRadius: 4,
                      offset: const Offset(0, 2),
                    )
                  ],
          ),
          child: Stack(
            clipBehavior: Clip.none,
            children: [
              // Module content
              Positioned.fill(
                child: _ModuleContent(module: module, isSelected: isSelected),
              ),

              // Resize handles (only when selected)
              if (isSelected) ...[
                _ResizeHandle(
                    moduleId: module.id, handle: 'se', width: width, height: height),
                _ResizeHandle(
                    moduleId: module.id, handle: 'sw', width: width, height: height),
                _ResizeHandle(
                    moduleId: module.id, handle: 'ne', width: width, height: height),
                _ResizeHandle(
                    moduleId: module.id, handle: 'nw', width: width, height: height),
              ],
            ],
          ),
        ),
      ),
    );
  }
}

class _ModuleContent extends StatelessWidget {
  final PlacedModule module;
  final bool isSelected;
  const _ModuleContent({required this.module, required this.isSelected});

  @override
  Widget build(BuildContext context) {
    final w = module.gridWidth * CanvasModel.gridUnit;
    final h = module.gridHeight * CanvasModel.gridUnit;
    final isCompact = w < 60 || h < 40;

    return Padding(
      padding: const EdgeInsets.all(4),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(
            module.type.icon,
            color: Colors.white,
            size: isCompact ? 14 : 22,
          ),
          if (!isCompact) ...[
            const SizedBox(height: 4),
            Text(
              module.type.label,
              style: TextStyle(
                color: Colors.white,
                fontSize: w > 80 ? 11 : 9,
                fontWeight: FontWeight.w600,
                letterSpacing: 0.3,
              ),
              textAlign: TextAlign.center,
              maxLines: 2,
              overflow: TextOverflow.ellipsis,
            ),
          ],
        ],
      ),
    );
  }
}

/// A corner resize handle widget.
class _ResizeHandle extends StatelessWidget {
  final String moduleId;
  final String handle;
  final double width;
  final double height;

  const _ResizeHandle({
    required this.moduleId,
    required this.handle,
    required this.width,
    required this.height,
  });

  static const double _hs = ModuleWidget._handleSize;

  @override
  Widget build(BuildContext context) {
    final model = context.read<CanvasModel>();

    double? left, top, right, bottom;
    if (handle.contains('w')) left = -_hs / 2;
    if (handle.contains('e')) right = -_hs / 2;
    if (handle.contains('n')) top = -_hs / 2;
    if (handle.contains('s')) bottom = -_hs / 2;

    MouseCursor cursor;
    if (handle == 'se' || handle == 'nw') {
      cursor = SystemMouseCursors.resizeUpLeftDownRight;
    } else {
      cursor = SystemMouseCursors.resizeUpRightDownLeft;
    }

    return Positioned(
      left: left,
      top: top,
      right: right,
      bottom: bottom,
      child: GestureDetector(
        behavior: HitTestBehavior.opaque,
        onPanUpdate: (d) =>
            model.resizeModule(moduleId, handle, d.delta.dx, d.delta.dy),
        onPanEnd: (_) => model.commitResize(),
        child: MouseRegion(
          cursor: cursor,
          child: Container(
            width: _hs,
            height: _hs,
            decoration: BoxDecoration(
              color: AppTheme.handleColor,
              shape: BoxShape.circle,
              border: Border.all(color: AppTheme.selectionBorder, width: 1.5),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withOpacity(0.4),
                  blurRadius: 3,
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
