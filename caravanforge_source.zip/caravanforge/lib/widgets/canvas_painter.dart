import 'package:flutter/material.dart';
import '../providers/canvas_model.dart';
import '../utils/app_theme.dart';

/// Paints the caravan outline and grid on the canvas background.
class CanvasPainter extends CustomPainter {
  final bool showGrid;

  const CanvasPainter({required this.showGrid});

  @override
  void paint(Canvas canvas, Size size) {
    _drawCaravanOutline(canvas, size);
    if (showGrid) _drawGrid(canvas, size);
  }

  void _drawCaravanOutline(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = const Color(0xFF3A3A5C)
      ..style = PaintingStyle.fill;

    // Rounded rectangle representing caravan floor plan
    final rRect = RRect.fromRectAndRadius(
      Rect.fromLTWH(0, 0, size.width, size.height),
      const Radius.circular(30),
    );
    canvas.drawRRect(rRect, paint);

    // Outline
    final outlinePaint = Paint()
      ..color = const Color(0xFF5A5A8A)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 2.0;
    canvas.drawRRect(rRect, outlinePaint);
  }

  void _drawGrid(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = AppTheme.gridLine
      ..strokeWidth = 0.5;

    final g = CanvasModel.gridUnit;
    for (double x = g; x < size.width; x += g) {
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), paint);
    }
    for (double y = g; y < size.height; y += g) {
      canvas.drawLine(Offset(0, y), Offset(size.width, y), paint);
    }
  }

  @override
  bool shouldRepaint(CanvasPainter old) => old.showGrid != showGrid;
}
