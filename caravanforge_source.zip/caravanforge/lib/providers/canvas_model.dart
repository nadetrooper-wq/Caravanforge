import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:uuid/uuid.dart';
import '../models/module_type.dart';
import '../models/placed_module.dart';

const _kSaveKey = 'caravanforge_layout';
const _uuid = Uuid();

/// Central state model for the canvas. Manages placed modules,
/// selection, grid settings, undo/redo, and persistence.
class CanvasModel extends ChangeNotifier {
  // Layout constants
  static const double gridUnit = 20.0;
  static const int canvasGridCols = 20;
  static const int canvasGridRows = 36;

  double get canvasWidth => canvasGridCols * gridUnit;
  double get canvasHeight => canvasGridRows * gridUnit;

  final List<PlacedModule> _modules = [];
  String? _selectedId;
  bool _snapToGrid = true;

  List<PlacedModule> get modules => List.unmodifiable(_modules);
  String? get selectedId => _selectedId;
  bool get snapToGrid => _snapToGrid;

  PlacedModule? get selectedModule => _selectedId == null
      ? null
      : _modules.where((m) => m.id == _selectedId).firstOrNull;

  // Undo/Redo
  final List<List<Map<String, dynamic>>> _undoStack = [];
  final List<List<Map<String, dynamic>>> _redoStack = [];

  bool get canUndo => _undoStack.isNotEmpty;
  bool get canRedo => _redoStack.isNotEmpty;

  void _saveSnapshot() {
    _undoStack.add(_modules.map((m) => m.toJson()).toList());
    _redoStack.clear();
    if (_undoStack.length > 50) _undoStack.removeAt(0);
  }

  void _restoreSnapshot(List<Map<String, dynamic>> snap) {
    _modules
      ..clear()
      ..addAll(snap.map((j) => PlacedModule.fromJson(j)));
    _selectedId = null;
    notifyListeners();
    _persist();
  }

  void undo() {
    if (_undoStack.isEmpty) return;
    _redoStack.add(_modules.map((m) => m.toJson()).toList());
    _restoreSnapshot(_undoStack.removeLast());
  }

  void redo() {
    if (_redoStack.isEmpty) return;
    _undoStack.add(_modules.map((m) => m.toJson()).toList());
    _restoreSnapshot(_redoStack.removeLast());
  }

  // Module operations

  void addModule(ModuleType type) {
    _saveSnapshot();
    final defaultSize = type.defaultGridSize;
    final gridX = ((canvasGridCols / 2) - defaultSize.width / 2)
        .clamp(0.0, canvasGridCols - defaultSize.width.toDouble());
    final gridY = ((canvasGridRows / 2) - defaultSize.height / 2)
        .clamp(0.0, canvasGridRows - defaultSize.height.toDouble());

    final module = PlacedModule(
      id: _uuid.v4(),
      type: type,
      gridX: gridX,
      gridY: gridY,
      gridWidth: defaultSize.width,
      gridHeight: defaultSize.height,
    );
    _modules.add(module);
    _selectedId = module.id;
    notifyListeners();
    _persist();
  }

  void moveModule(String id, double deltaX, double deltaY) {
    final idx = _modules.indexWhere((m) => m.id == id);
    if (idx == -1) return;
    final m = _modules[idx];

    double newX = m.gridX + deltaX / gridUnit;
    double newY = m.gridY + deltaY / gridUnit;
    newX = newX.clamp(0.0, canvasGridCols - m.gridWidth);
    newY = newY.clamp(0.0, canvasGridRows - m.gridHeight);

    _modules[idx] = m.copyWith(gridX: newX, gridY: newY);
    notifyListeners();
  }

  void commitMove() {
    _saveSnapshot();
    _persist();
  }

  void snapMove(String id) {
    if (!_snapToGrid) return;
    final idx = _modules.indexWhere((m) => m.id == id);
    if (idx == -1) return;
    final m = _modules[idx];
    _modules[idx] = m.copyWith(
      gridX: m.gridX.roundToDouble(),
      gridY: m.gridY.roundToDouble(),
    );
    notifyListeners();
  }

  void resizeModule(String id, String handle, double deltaX, double deltaY) {
    final idx = _modules.indexWhere((m) => m.id == id);
    if (idx == -1) return;
    final m = _modules[idx];

    double newX = m.gridX;
    double newY = m.gridY;
    double newW = m.gridWidth;
    double newH = m.gridHeight;

    final dxGrid = deltaX / gridUnit;
    final dyGrid = deltaY / gridUnit;

    if (handle.contains('e')) newW += dxGrid;
    if (handle.contains('s')) newH += dyGrid;
    if (handle.contains('w')) { newX += dxGrid; newW -= dxGrid; }
    if (handle.contains('n')) { newY += dyGrid; newH -= dyGrid; }

    newW = newW.clamp(2.0, double.infinity);
    newH = newH.clamp(2.0, double.infinity);
    newX = newX.clamp(0.0, (canvasGridCols - newW).toDouble());
    newY = newY.clamp(0.0, (canvasGridRows - newH).toDouble());
    if (newX + newW > canvasGridCols) newW = canvasGridCols - newX;
    if (newY + newH > canvasGridRows) newH = canvasGridRows - newY;

    _modules[idx] = m.copyWith(gridX: newX, gridY: newY, gridWidth: newW, gridHeight: newH);
    notifyListeners();
  }

  void commitResize() {
    _saveSnapshot();
    _persist();
  }

  void deleteSelected() {
    if (_selectedId == null) return;
    _saveSnapshot();
    _modules.removeWhere((m) => m.id == _selectedId);
    _selectedId = null;
    notifyListeners();
    _persist();
  }

  void selectModule(String? id) {
    if (_selectedId == id) return;
    _selectedId = id;
    notifyListeners();
  }

  void clearCanvas() {
    if (_modules.isEmpty) return;
    _saveSnapshot();
    _modules.clear();
    _selectedId = null;
    notifyListeners();
    _persist();
  }

  void toggleSnapToGrid() {
    _snapToGrid = !_snapToGrid;
    notifyListeners();
  }

  // Persistence

  Future<void> _persist() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final jsonList = _modules.map((m) => m.toJson()).toList();
      await prefs.setString(_kSaveKey, jsonEncode(jsonList));
    } catch (e) {
      debugPrint('CaravanForge: persist error: $e');
    }
  }

  Future<void> loadSaved() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final raw = prefs.getString(_kSaveKey);
      if (raw == null) return;
      final list = jsonDecode(raw) as List<dynamic>;
      _modules.clear();
      for (final item in list) {
        _modules.add(PlacedModule.fromJson(item as Map<String, dynamic>));
      }
      notifyListeners();
    } catch (e) {
      debugPrint('CaravanForge: load error: $e');
    }
  }

  String exportJson() {
    final jsonList = _modules.map((m) => m.toJson()).toList();
    return const JsonEncoder.withIndent('  ').convert(jsonList);
  }
}
