# CaravanForge — Build Instructions

## Prerequisites

- Flutter SDK ≥ 3.10.0 (with Dart ≥ 3.0.0)
- Android SDK with build-tools ≥ 34.0.0
- Java 17 (OpenJDK recommended)

Verify your environment:
```
flutter doctor
```

---

## Project Setup

1. Copy all source files into a new Flutter project:
   ```
   flutter create caravanforge
   cd caravanforge
   ```
   Then replace `lib/`, `pubspec.yaml`, and Android files with those provided.

2. Install dependencies:
   ```
   flutter pub get
   ```

---

## Android Configuration

### android/app/build.gradle

Replace the default `android/app/build.gradle` content with:

```gradle
plugins {
    id "com.android.application"
    id "kotlin-android"
    id "dev.flutter.flutter-gradle-plugin"
}

android {
    namespace = "com.example.caravanforge"
    compileSdk = flutter.compileSdkVersion
    ndkVersion = flutter.ndkVersion

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = JavaVersion.VERSION_17
    }

    defaultConfig {
        applicationId = "com.example.caravanforge"
        minSdk = 21
        targetSdk = flutter.targetSdkVersion
        versionCode = flutter.versionCode
        versionName = flutter.versionName
    }

    buildTypes {
        release {
            signingConfig = signingConfigs.debug   // Replace with real keystore for production
            minifyEnabled = false
            shrinkResources = false
        }
    }
}

flutter {
    source = "../.."
}
```

### android/app/src/main/AndroidManifest.xml

Ensure the `<manifest>` tag includes:
```xml
<uses-permission android:name="android.permission.INTERNET"/>
```

The rest of the default Flutter manifest is fine (no special permissions needed beyond INTERNET for future updates).

---

## Signing (Production APK)

For a signed release APK:

1. Generate a keystore:
   ```
   keytool -genkey -v -keystore ~/caranvan_key.jks \
     -alias caravanforge -keyalg RSA -keysize 2048 -validity 10000
   ```

2. Create `android/key.properties`:
   ```
   storePassword=YOUR_STORE_PASSWORD
   keyPassword=YOUR_KEY_PASSWORD
   keyAlias=caravanforge
   storeFile=/path/to/caranvan_key.jks
   ```

3. Update `android/app/build.gradle` to reference the keystore:
   ```gradle
   def keystoreProperties = new Properties()
   def keystorePropertiesFile = rootProject.file('key.properties')
   if (keystorePropertiesFile.exists()) {
       keystoreProperties.load(new FileInputStream(keystorePropertiesFile))
   }

   android {
       ...
       signingConfigs {
           release {
               keyAlias keystoreProperties['keyAlias']
               keyPassword keystoreProperties['keyPassword']
               storeFile keystoreProperties['storeFile'] ? file(keystoreProperties['storeFile']) : null
               storePassword keystoreProperties['storePassword']
           }
       }
       buildTypes {
           release {
               signingConfig signingConfigs.release
           }
       }
   }
   ```

---

## Building the APK

### Debug APK (quick test):
```
flutter build apk --debug
```
Output: `build/app/outputs/flutter-apk/app-debug.apk`

### Release APK:
```
flutter build apk --release
```
Output: `build/app/outputs/flutter-apk/app-release.apk`

### Fat APK (all ABIs, largest file, easiest):
```
flutter build apk --release --split-per-abi
```
Produces separate optimized APKs for:
- `app-armeabi-v7a-release.apk` (32-bit ARM)
- `app-arm64-v8a-release.apk`   (64-bit ARM — most modern Android)
- `app-x86_64-release.apk`     (x86_64 emulator)

### App Bundle (for Play Store upload):
```
flutter build appbundle --release
```
Output: `build/app/outputs/bundle/release/app-release.aab`

---

## Install on Device

```
flutter install
```
or manually:
```
adb install build/app/outputs/flutter-apk/app-release.apk
```

---

## Troubleshooting

| Issue | Fix |
|-------|-----|
| `flutter doctor` shows missing Android SDK | Install Android Studio and run `flutter config --android-sdk /path/to/sdk` |
| Gradle build fails with Java error | Set `JAVA_HOME` to Java 17: `export JAVA_HOME=/usr/lib/jvm/java-17-openjdk` |
| `minSdkVersion` errors | Ensure `minSdk = 21` in build.gradle |
| `shared_preferences` not found | Run `flutter pub get` first |
