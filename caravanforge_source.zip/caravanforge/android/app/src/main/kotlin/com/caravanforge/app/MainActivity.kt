package com.caravanforge.app

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
